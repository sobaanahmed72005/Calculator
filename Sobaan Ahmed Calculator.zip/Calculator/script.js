let currentInput  = '0';
let previousInput = '';
let operator      = null;
let shouldReset   = false;

const resultEl     = document.getElementById('result');
const expressionEl = document.getElementById('expression');
const sym = { '+':'+', '-':'−', '*':'×', '/':'÷' };

function updateDisplay(v) {
  const s = String(v);
  resultEl.textContent = s.length > 11 ? parseFloat(v).toExponential(4) : s;
  resultEl.classList.toggle('error', v === 'Error');
}

function appendNum(d) {
  if (shouldReset) { currentInput = d; shouldReset = false; }
  else {
    if (currentInput === '0' && d !== '.') currentInput = d;
    else { if (currentInput.length >= 11) return; currentInput += d; }
  }
  updateDisplay(currentInput);
}

function appendDot() {
  if (shouldReset) { currentInput = '0.'; shouldReset = false; updateDisplay(currentInput); return; }
  if (!currentInput.includes('.')) { currentInput += '.'; updateDisplay(currentInput); }
}

function appendOp(op) {
  if (operator && !shouldReset) calculate(true);
  previousInput = currentInput; operator = op; shouldReset = true;
  expressionEl.textContent = `${previousInput} ${sym[op]}`;
}

function calculate(chained = false) {
  if (!operator || (!chained && shouldReset)) return;
  const a = parseFloat(previousInput), b = parseFloat(currentInput);
  let result;
  if (operator === '+') result = a + b;
  else if (operator === '-') result = a - b;
  else if (operator === '*') result = a * b;
  else if (operator === '/') { if (b === 0) { displayError(); return; } result = a / b; }
  result = parseFloat(result.toPrecision(12));
  if (!chained) {
    expressionEl.textContent = `${previousInput} ${sym[operator]} ${b} =`;
    operator = null; shouldReset = true;
  }
  currentInput = String(result);
  updateDisplay(currentInput);
}

function clearAll() {
  currentInput = '0'; previousInput = ''; operator = null; shouldReset = false;
  updateDisplay('0'); expressionEl.textContent = '';
}

function deleteLast() {
  if (shouldReset || currentInput === 'Error') { clearAll(); return; }
  currentInput = currentInput.length <= 1 || (currentInput.length === 2 && currentInput[0] === '-') ? '0' : currentInput.slice(0, -1);
  updateDisplay(currentInput);
}

function toggleSign() {
  if (currentInput === '0' || currentInput === 'Error') return;
  currentInput = currentInput[0] === '-' ? currentInput.slice(1) : '-' + currentInput;
  updateDisplay(currentInput);
}

function percentage() {
  const v = parseFloat(currentInput); if (isNaN(v)) return;
  currentInput = operator && previousInput ? String(parseFloat(previousInput) * v / 100) : String(v / 100);
  updateDisplay(currentInput); shouldReset = true;
}

function squareRoot() {
  const v = parseFloat(currentInput); if (v < 0) { displayError(); return; }
  expressionEl.textContent = `√(${currentInput}) =`;
  currentInput = String(parseFloat(Math.sqrt(v).toPrecision(12)));
  updateDisplay(currentInput); shouldReset = true;
}

function square() {
  const v = parseFloat(currentInput);
  expressionEl.textContent = `(${currentInput})² =`;
  currentInput = String(parseFloat((v * v).toPrecision(12)));
  updateDisplay(currentInput); shouldReset = true;
}

function inverse() {
  const v = parseFloat(currentInput); if (v === 0) { displayError(); return; }
  expressionEl.textContent = `1/(${currentInput}) =`;
  currentInput = String(parseFloat((1 / v).toPrecision(12)));
  updateDisplay(currentInput); shouldReset = true;
}

function displayError() {
  currentInput = 'Error'; updateDisplay('Error');
  expressionEl.textContent = ''; operator = null; shouldReset = true;
}

document.addEventListener('keydown', e => {
  if (e.key >= '0' && e.key <= '9') appendNum(e.key);
  else if (e.key === '.') appendDot();
  else if (e.key === '+') appendOp('+');
  else if (e.key === '-') appendOp('-');
  else if (e.key === '*') appendOp('*');
  else if (e.key === '/') { e.preventDefault(); appendOp('/'); }
  else if (e.key === 'Enter' || e.key === '=') calculate();
  else if (e.key === 'Backspace') deleteLast();
  else if (e.key === 'Escape') clearAll();
  else if (e.key === '%') percentage();
});