# Calculator

A simple calculator built with HTML, CSS, and JavaScript.

---

## File Structure

calculator/
├── index.html
├── style.css
├── script.js
└── README.md

---

## Features

- Addition, subtraction, multiplication, division
- Square root, square, inverse (1/x)
- Percentage, toggle sign (+/−), backspace
- Chained operations
- Division by zero and negative square root error handling
- Full keyboard support

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| 0–9 | Digits |
| . | Decimal |
| + − * / | Operators |
| Enter or = | Calculate |
| Backspace | Delete last digit |
| Escape | Clear all |
| % | Percentage |

---

## How to Run

Open index.html in any browser. No build step, no server needed.

---

## How It Works

Three state variables drive everything:

| Variable | Purpose |
|----------|---------|
| currentInput | Number on screen |
| previousInput | Number stored before operator |
| operator | Pending operation (+, −, ×, ÷) |

Example — 8 × 3 =
1. appendNum('8') → currentInput = 8
2. appendOp('*') → previousInput = 8, operator = *
3. appendNum('3') → currentInput = 3
4. calculate() → 8 × 3 = 24